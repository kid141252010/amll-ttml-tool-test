/* @ts-self-types="./amll_lyric.d.ts" */

import * as wasm from "./amll_lyric_bg.wasm";
import { __wbg_set_wasm } from "./amll_lyric_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    decryptQrcHex, parseEslrc, parseLrc, parseLys, parseQrc, parseTTML, parseYrc, stringifyAss, stringifyEslrc, stringifyLrc, stringifyLys, stringifyQrc, stringifyTTML, stringifyYrc, wasm_start
} from "./amll_lyric_bg.js";
